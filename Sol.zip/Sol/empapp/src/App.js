import React, { Component } from 'react';
import { Provider } from 'react-redux';
import configureStore from './emp/store/ConfigureStore';
import EmpApp from './emp/pages/EmpApp';

const store = configureStore();

class App extends Component {
  render() {
    return (
    		
    	<Provider store={store}>
        	<EmpApp/>
        </Provider>
    );
  }
}

export default App;
