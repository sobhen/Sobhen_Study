import axios from 'axios';

class EmpApi {
	static getEmpList(){
		return axios.get({
			url:'http://localhost:3000/emps'
		});
	}
}

export default EmpApi;
