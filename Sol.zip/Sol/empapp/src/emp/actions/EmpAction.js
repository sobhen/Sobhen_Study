import EmpApi from '../api/EmpApi';

export const LOAD_EMP_LIST = 'LOAD_EMP_LIST';
export const LOAD_EMP_LIST_SUCCESS = 'LOAD_EMP_LIST_SUCCESS';
export const ADD_EMP = 'ADD_EMP';
export const ADD_EMP_SUBMIT = 'ADD_EMP_SUBMIT';

export function addButtonClick(){
	console.log('From Action addButtonClick');
	return function(dispatch){
		dispatch({type:ADD_EMP})
	}
}

export function loadEmpListSucess(emps){
	return {
		type:LOAD_EMP_LIST_SUCCESS,emps
	}
}
export function loadEmpList(){
	//Call to actual API
	/*return function(dispatch){
		return EmpApi.getEmpList().then((res) => {
			dispatch(loadEmpListSucess(res.data))
		})
	}	*/
	
	let emps = [
		  {
			    'empId': 'EMP001',
			    "name": "Sobhen Mishra",
			    "dateOfJoining": "10-07-2013",
			    "dept": {
			      "deptName": "IT"
			    }
			  },
			  {
			    "empId": "EMP002",
			    "name": "John",
			    "dateOfJoining": "23-09-2014",
			    "dept": {
			      "deptName": "HR"
			    }
			  }
			];
	return function(dispatch){
		dispatch(loadEmpListSucess(emps))
	}
}
