import {LOAD_EMP_LIST_SUCCESS,LOAD_EMP_LIST,ADD_EMP,ADD_EMP_SUBMIT} from '../actions/EmpAction';

const INITIAL_STATE = { empList: {emps: []},  
						newEmp:{emp:null}, 
						activeEmp:{emp:null}, 
						deletedEmp: {emp: null},
						action:''
					  };

export default function(state = INITIAL_STATE, action){
	
	let error;
	
	 switch(action.type) {
	 
	 	case LOAD_EMP_LIST:
	 		return Object.assign(
	 			{},state,{empList: {emps: []}}
	 		) 
	 		
	 	case LOAD_EMP_LIST_SUCCESS:
	 		return Object.assign(
	 			{},state,{empList: {emps: action.emps}}
	 		) 
	 		
	 	case ADD_EMP:
	 		return Object.assign(
	 			{},state,{action: 'Add'}
	 		) 
	 		
	 	default:
	 	    return state;
	 }
}