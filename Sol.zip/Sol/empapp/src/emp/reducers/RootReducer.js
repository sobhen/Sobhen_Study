import { combineReducers } from 'redux';
import { reducer as formReducer } from 'redux-form';

import EmpReducer from './EmpReducer';


const rootReducer = combineReducers({
  emps: EmpReducer, 
  form: formReducer
});

export default rootReducer;
