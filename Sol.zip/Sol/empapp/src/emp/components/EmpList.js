import React, { Component } from 'react';

class EmpList extends Component {
	componentWillMount() {
	    this.props.loadEmpList();
	}
	
	 render() {
		 const { emps } = this.props.empList;
		 
		 return (
				 <div className="card card-outline-primary">
				 	<div className="card-header bg-primary">Employees</div>
				 	
				 	<div className="card-block">
				 		
				 		<table className="table table-sm table-bordered table-striped table-hover">
				 			<thead className="thead-default">
				 				<tr>
					 				<th>Emp ID</th>
					 				<th>Name</th>
					 				<th>Date of Join</th>
					 				<th>Department</th>
					 				<th>Actions</th>
				 				</tr>
				 			</thead>
				 			<tbody>
				 				
				 				{
				 					emps.map((emp,idx)=>{
				 						return (
				 							<tr key={idx}>
					 							<td>{emp.empId}</td>
					 							<td>{emp.name}</td>
					 							<td>{emp.dateOfJoining}</td>
					 							<td>{emp.dept.deptName}</td>
					 							<td>
					 							<button className="btn btn-link btn-sm"><i className="fa fa-pencil-square-o" aria-hidden="true"></i></button>
				 								<button className="btn btn-link btn-sm"><i className="fa fa-trash-o" aria-hidden="true"></i></button>
					 							</td> 
					 						</tr>
				 						)
				 					})
				 				}
				 				
				 			</tbody>
				 		</table>
				 	</div>
				 </div>
		 );
	 }
}

export default EmpList;