import React, { Component } from 'react';

import EmpList from '../containers/EmpListContainer';
import AddEditEmp from '../containers/AddEditEmpContainer';

class EmpAppComponent extends Component {
	componentWillMount() {
	    //this.props.loadEmpList();
	}

	render() {
		const { action } = this.props.action;
		if(this.props.action == 'Add'){
			return(
				<AddEditEmp/>
			);
		}else{
			return(
					<div>
						<button className="btn btn-primary" onClick={this.props.addClick}>Add Employee</button><br/><br/>
						<EmpList/>
					</div>
					
				);
		}
		
	}
}

export default EmpAppComponent;