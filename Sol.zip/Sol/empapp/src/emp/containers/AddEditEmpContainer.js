import { connect } from 'react-redux'

import AddEditEmp from '../components/AddEditEmp';
import {loadEmpList} from '../actions/EmpAction';

const mapStateToProps = (state) => {
  return { 
	  empList: state.emps.empList
  };
}

const mapDispatchToProps = (dispatch) => {
  return {
    addEmp: (values) => {
      console.log('Values Submitted :: '+JSON.stringify(values));
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(AddEditEmp);