import { connect } from 'react-redux'

import EmpAppComponent from '../components/EmpAppComponent';
import {addButtonClick} from '../actions/EmpAction';

const mapStateToProps = (state) => {
  return { 
	  action: state.emps.action
  };
}

const mapDispatchToProps = (dispatch) => {
  return {
    addClick: () => {
     dispatch(addButtonClick())
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(EmpAppComponent);