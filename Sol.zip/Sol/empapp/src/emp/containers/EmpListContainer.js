import { connect } from 'react-redux'

import EmpList from '../components/EmpList';
import {loadEmpList} from '../actions/EmpAction';

const mapStateToProps = (state) => {
  return { 
	  empList: state.emps.empList
  };
}

const mapDispatchToProps = (dispatch) => {
  return {
    loadEmpList: () => {
      dispatch(loadEmpList());
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(EmpList);