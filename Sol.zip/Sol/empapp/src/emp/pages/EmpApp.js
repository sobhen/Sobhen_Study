import React, { Component } from 'react';
import EmpList from '../containers/EmpListContainer';
import AddEditEmp from '../containers/AddEditEmpContainer';
import EmpAppComponent from '../containers/EmpAppContainer';
import { Link, Switch, Route, Redirect,HashRouter } from 'react-router-dom';
import { createBrowserHistory } from 'history';

const history = createBrowserHistory();

class EmpApp extends Component {
	
  componentWillMount() {
	 
  }
  render() {
    return (
    <HashRouter history={history}>	
      <div className="m-5">  
      	 <EmpAppComponent/>	
      	 <Switch>
      	 	<Route path="/empList" name="EmpList" component={EmpList}/>
      	 	<Route path="/addEditEmp" name="AddEditEmp" component={AddEditEmp}/>      	 	
      	 </Switch>
      </div>
     </HashRouter>
    );
  }
}


export default EmpApp;
