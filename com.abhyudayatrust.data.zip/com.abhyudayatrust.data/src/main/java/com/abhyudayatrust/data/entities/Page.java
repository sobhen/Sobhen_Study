package com.abhyudayatrust.data.entities;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "T_PAGES")
public class Page implements Serializable {

	private static final long serialVersionUID = 5956950907107229864L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PAGE_ID")
	private Integer pageId;

	@Column(name = "PAGE")
	private String page;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SUBMENU_ID")
	private SubMenu subMenu;
	
	@OneToMany(mappedBy="page",cascade=CascadeType.ALL)
	private Set<PageFunction> pageFunctions;
	

	public Integer getPageId() {
		return pageId;
	}

	public void setPageId(Integer pageId) {
		this.pageId = pageId;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public SubMenu getSubMenu() {
		return subMenu;
	}

	public void setSubMenu(SubMenu subMenu) {
		this.subMenu = subMenu;
	}

	public Set<PageFunction> getPageFunctions() {
		return pageFunctions;
	}

	public void setPageFunctions(Set<PageFunction> pageFunctions) {
		this.pageFunctions = pageFunctions;
	}

}
