package com.abhyudayatrust.data.dao;

import java.util.List;

import org.hibernate.Session;

import com.abhyudayatrust.data.entities.Role;
import com.abhyudayatrust.data.util.HibernateUtil;

public class RoleDao extends BaseDao<Role> {

	@Override
	public Role getById(Integer id) {		
		Role role = getSession().get(Role.class, id);
		return role;
	}

	@SuppressWarnings("unchecked")
	@Override	
	public List<Role> listAll() {
		List<Role> roleList = getSession().createQuery("from Role").list();
		return roleList;
	}

	public Integer createRole(Role role){
		Integer generatedId = null;
		
		getSession().save(role);
		
		return generatedId;
	}
	
}
