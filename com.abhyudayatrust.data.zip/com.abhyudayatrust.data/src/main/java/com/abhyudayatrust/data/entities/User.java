package com.abhyudayatrust.data.entities;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;


@Entity
@Table(name="t_user",uniqueConstraints={
		@UniqueConstraint(columnNames={"user_id"})
})
public class User implements Serializable{

	private static final long serialVersionUID = -2519461924581098071L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;
	
	@Column(name="user_name",nullable=false)	
	private String userName;
	
	@Column(name="user_id",nullable=false)
	private String userId;
	
	@Column(name="user_status",nullable=false)
	private char userStatus;
	
	@Column(name="login_password",nullable=false)
	private String loginPassword;
	
	@Column(name="validity_from",nullable=false)
	private Date validityFrom;
	
	@Column(name="validity_to",nullable=false)
	private Date validityTo;
	
	@Column(name="last_login_time",nullable=true)
	private Timestamp lastLoginTime;
	
	@Column(name="fail_login",nullable=true)
	private Integer failLogin;
	
	@Column(name="new_pass_flag",nullable=false)	
	private boolean newPassFlag;
	
	@Column(name="chng_pass_date",nullable=true)
	private Date passwordChangeDate;
	
	@Column(name="password_retries",nullable=true)
	private Integer passwordRetries;
	
	@Column(name="password_salt",nullable=true)
	private byte[] passwordSalt;

	
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="ROLE_ID")
	private Role role;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public char getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(char userStatus) {
		this.userStatus = userStatus;
	}

	public String getLoginPassword() {
		return loginPassword;
	}

	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}

	public Date getValidityFrom() {
		return validityFrom;
	}

	public void setValidityFrom(Date validityFrom) {
		this.validityFrom = validityFrom;
	}

	public Date getValidityTo() {
		return validityTo;
	}

	public void setValidityTo(Date validityTo) {
		this.validityTo = validityTo;
	}

	public Timestamp getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(Timestamp lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public Integer getFailLogin() {
		return failLogin;
	}

	public void setFailLogin(Integer failLogin) {
		this.failLogin = failLogin;
	}

	public boolean isNewPassFlag() {
		return newPassFlag;
	}

	public void setNewPassFlag(boolean newPassFlag) {
		this.newPassFlag = newPassFlag;
	}

	public Date getPasswordChangeDate() {
		return passwordChangeDate;
	}

	public void setPasswordChangeDate(Date passwordChangeDate) {
		this.passwordChangeDate = passwordChangeDate;
	}

	public Integer getPasswordRetries() {
		return passwordRetries;
	}

	public void setPasswordRetries(Integer passwordRetries) {
		this.passwordRetries = passwordRetries;
	}

	public byte[] getPasswordSalt() {
		return passwordSalt;
	}

	public void setPasswordSalt(byte[] passwordSalt) {
		this.passwordSalt = passwordSalt;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	
		
	
}
