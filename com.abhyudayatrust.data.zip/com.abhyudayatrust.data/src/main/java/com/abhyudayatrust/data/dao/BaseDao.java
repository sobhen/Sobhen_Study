package com.abhyudayatrust.data.dao;

import org.hibernate.Session;

import com.abhyudayatrust.data.util.HibernateUtil;

public  abstract class  BaseDao<T> implements IBaseDao<T> {
	
	public Session getSession(){
		return HibernateUtil.getSession();
	}
	
}
