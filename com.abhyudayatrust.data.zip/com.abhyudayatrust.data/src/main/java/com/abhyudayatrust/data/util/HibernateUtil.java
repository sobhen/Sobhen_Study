package com.abhyudayatrust.data.util;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.service.ServiceRegistry;

public final class HibernateUtil {

	static {
		buildSessionFactory();
	}

	public static SessionFactory getSessionFactory() {
		SessionFactory sessionFactory = null;
		try {
			sessionFactory = (SessionFactory) new InitialContext()
					.lookup("java:jboss/hibernate/SessionFactory");
			
			
		} catch (NamingException e) {
			if (null == sessionFactory) {
				sessionFactory = buildSessionFactory();
			}
		}
		return sessionFactory;
	}

	public static Session getSession() {
		Session session = null;
		
		try{
			session = getSessionFactory().getCurrentSession();	
		}catch(Exception ex){
			if(null == session){
				session = getSessionFactory().openSession();
			}
		}
		return session;				
	}

	private static SessionFactory buildSessionFactory() {
		
		String hibernateConfigFileName = System.getProperty("hibernateConfigFileName","hibernate.cfg.xml");
		
		SessionFactory sessionFactory = null;
		ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
				.configure(hibernateConfigFileName).build();
		Metadata metadata = new MetadataSources(serviceRegistry)
				.buildMetadata();
		sessionFactory = metadata.buildSessionFactory();

		return sessionFactory;
	}
}
