package com.abhyudayatrust.services;

public interface IService {

}
