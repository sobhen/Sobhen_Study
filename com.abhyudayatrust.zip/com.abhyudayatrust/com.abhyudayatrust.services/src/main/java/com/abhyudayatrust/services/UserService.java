package com.abhyudayatrust.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.naming.InitialContext;
import javax.transaction.UserTransaction;

import org.modelmapper.PropertyMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.abhyudayatrust.common.model.Employee;
import com.abhyudayatrust.common.util.ModelMapperUtil;
import com.abhyudayatrust.data.dao.UserDao;
import com.abhyudayatrust.data.entities.User;

@Service("userService")
public class UserService implements IService,UserDetailsService {
	
	@Autowired
	private UserDao userDao;
		
	@Override
	public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
		
		User userEntity =  userDao.getUserDetail(userId);
		
		
		if(null == userEntity){
			throw new UsernameNotFoundException("User :: "+userId+":: Not Found...");
		}
		
		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		authorities.add(new SimpleGrantedAuthority("ROLE_"+ userEntity.getRole().getRoleName()));
				
		 com.abhyudayatrust.common.model.User userModel = new com.abhyudayatrust.common.model.User(userEntity.getUserId(),
				 userEntity.getLoginPassword(),userEntity.getUserStatus() == 'A' ? true : false,
				true, true, true,authorities);
		 
		 userModel.setLastLoginTime(userEntity.getLastLoginTime());
		 userModel.setNewPassFlag(userEntity.isNewPassFlag());
		 userModel.setPasswordChangeDate(userEntity.getPasswordChangeDate());
		 userModel.setPasswordRetries(userEntity.getPasswordRetries());
		 userModel.setUserDisplayName(userEntity.getUserName());
		 userModel.setValidityFrom(userEntity.getValidityFrom());
		 userModel.setValidityTo(userEntity.getValidityTo());
		 userModel.setUserId(userEntity.getUserId());
		
		 userModel.setRole(ModelMapperUtil.toModel(userEntity.getRole(), com.abhyudayatrust.common.model.Role.class,
				 	new PropertyMap<com.abhyudayatrust.data.entities.Role, com.abhyudayatrust.common.model.Role>() {
			@Override
			protected void configure() {
				map().setRoleId(source.getRoleId());			
				map().setRoleName(source.getRoleName());
				map().setRoleDesc(source.getRoleDesc());
				map().setMenus(null);
			}
		}));
		 
		 userModel.setEmployee(ModelMapperUtil.toModel(userEntity.getEmployee(), Employee.class));
		 
		 return userModel;
	}
	
	/*
	 * Functionalities of updatePostLoginData method.
	 * 	1. Updates LastLoginTime of User
	 *  
	 */
	public void updatePostLoginData(com.abhyudayatrust.common.model.User userM){
		
		try{
			//UserTransaction tx = (UserTransaction) new InitialContext().lookup("java:jboss/UserTransaction");
			//tx.begin();
			
			//System.out.println("Transaction :: "+ tx);
			//User userE = ModelMapperUtil.toEntity(userM, User.class);
			
			userDao.updateLastLoginTime(userM.getUserId());
			/*if(1==1){
				throw new Exception("");
			}*/
			//tx.commit();
		}catch(Exception ex){
			
		}
		
	}
	
	
}
