package com.abhyudayatrust.services;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abhyudayatrust.data.dao.RoleDao;

@Service("roleService")
public class RoleService implements IService {

	@Autowired
	private RoleDao roleDao;

	public Map<Object, List<Object[]>> fetchMenusByRoleId(Integer roleId) {

		Map<Object, List<Object[]>> roleMenus = new LinkedHashMap<>();
		List<Object[]> tempList = null;
		Object prevKey = null;
		
		List<Object[]> meusList = new RoleDao().getRoleWithAccessByRoleId(5);
		
		if (!meusList.isEmpty()) {

			for (Object[] menu : meusList) {

				if (!roleMenus.containsKey(menu[0])) {

					if (null != prevKey && null != tempList) {
						roleMenus.put(prevKey, tempList);
					}

					roleMenus.put(menu[0], null);
					tempList = new ArrayList<>();

				}

				tempList.add(menu);
				prevKey = menu[0];
			}
			roleMenus.put(prevKey, tempList);
		}
		return roleMenus;
	}
}
