package com.abhyudayatrust.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abhyudayatrust.common.model.User;
import com.abhyudayatrust.common.util.ModelMapperUtil;
import com.abhyudayatrust.data.dao.AttendanceDao;
import com.abhyudayatrust.data.entities.Attendance;
import com.abhyudayatrust.data.entities.Employee;

@Service("attendanceService")
public class AttendanceService implements IService {

	@Autowired
	private AttendanceDao attendanceDao;

	public boolean hasUserMarkedAttendanceToday(User userM) {
		boolean hasUserMarkedAttendanceToday = false;

		Attendance attendance = attendanceDao.getAttendanceByDate(
				ModelMapperUtil.toEntity(userM.getEmployee(), Employee.class),
				new java.sql.Date(new java.util.Date().getTime()));
		
		if(null != attendance && null != attendance.getCheckInTime()){
			hasUserMarkedAttendanceToday = true;
		}
		
		return hasUserMarkedAttendanceToday;
	}
	
	public void markAttendance(){
		
	}
}
