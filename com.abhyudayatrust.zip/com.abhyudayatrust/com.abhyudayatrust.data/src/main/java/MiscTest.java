import java.util.HashSet;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;

import com.abhyudayatrust.common.model.Menu;
import com.abhyudayatrust.common.model.Role;
import com.abhyudayatrust.common.model.SubMenu;
import com.abhyudayatrust.data.entities.User;
import com.abhyudayatrust.data.util.HibernateUtil;


public class MiscTest {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSession();
		org.hibernate.Transaction tx = session.beginTransaction();
		
		Query query = session.createQuery("from User where userId=?");

		query.setString(0, "admin");

		User userEntity = (User) query.uniqueResult();
		
		
		 String prevMenu  = "";
		 
		 Role roleM = new Role();
		 roleM.setRoleId(userEntity.getRole().getRoleId());
		 roleM.setRoleDesc(userEntity.getRole().getRoleDesc());
		 roleM.setRoleName(userEntity.getRole().getRoleName());
		 
		 
		 Set<Menu> menuMSet = new HashSet<Menu>();
		 Set<SubMenu> submenuMSet = new HashSet<SubMenu>();
		 Menu menuM = null;
		 for(com.abhyudayatrust.data.entities.SubMenu submenuE : userEntity.getRole().getSubMenus()){
			 
			 if(prevMenu.equals("") || !prevMenu.equals(submenuE.getMenu().getMenu())){
				 menuM = new Menu();
				 menuM.setMenu(submenuE.getMenu().getMenu());
				 menuM.setSortOrder(submenuE.getMenu().getSortOrder());
				 menuMSet.add(menuM);
				 
				 prevMenu = menuM.getMenu();
			 }	
			 
			 
			 if(!menuM.getMenu().equals(submenuE.getMenu().getMenu())){
				 SubMenu subMenuM = new SubMenu();
				 subMenuM.setSubMenu(submenuE.getSubMenu());
				 subMenuM.setUrl(submenuE.getUrl());
				 subMenuM.setSortOrder(submenuE.getSortOrder());
				 submenuMSet.add(subMenuM);				 
			 }
			 
			 
			
			 menuM.setSubMenus(submenuMSet);
			 
		 }
		 roleM.setMenus(menuMSet);
		 
		
		 
		 
		 System.out.println(roleM);
	}

}
