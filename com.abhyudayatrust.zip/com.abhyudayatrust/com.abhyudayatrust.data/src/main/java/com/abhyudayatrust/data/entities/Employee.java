package com.abhyudayatrust.data.entities;

import java.io.Serializable;
import java.sql.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="T_EMPLOYEE")
public class Employee implements Serializable{

	private static final long serialVersionUID = -3198823268931119497L;

	@Id
	@Column(name="ID")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name="EMP_ID")
	private String empId;
	
	@Column(name="EMP_FIRST_NAME")
	private String firstName;
	
	@Column(name="EMP_MIDDLE_NAME")
	private String middleName;
	
	@Column(name="EMP_LAST_NAME")
	private String lastName;
	
	@Column(name="EMP_STATUS")
	private char empStatus;
	
	@Column(name="JOINING_DATE")
	private Date joiningDate;
	
	@Column(name="DOB")
	private Date dateOfBirth;
	
	@Column(name="GENDER")
	private char gender;
	
	@Column(name="MARK_ATTENDANCE_FLAG")
	private boolean markAttendanceFlag;
	
	
	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="ADDRESS_ID")
	private Address address;
	
	
	@OneToOne(fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	@JoinColumn(name="USER_ID")
	private User user;

	@OneToMany(mappedBy="employee",cascade=CascadeType.ALL)
	private Set<Attendance> attendance;

	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getEmpId() {
		return empId;
	}


	public void setEmpId(String empId) {
		this.empId = empId;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getMiddleName() {
		return middleName;
	}


	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public char getEmpStatus() {
		return empStatus;
	}


	public void setEmpStatus(char empStatus) {
		this.empStatus = empStatus;
	}


	public Date getJoiningDate() {
		return joiningDate;
	}


	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}


	public Date getDateOfBirth() {
		return dateOfBirth;
	}


	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}


	public char getGender() {
		return gender;
	}


	public void setGender(char gender) {
		this.gender = gender;
	}


	public boolean isMarkAttendanceFlag() {
		return markAttendanceFlag;
	}


	public void setMarkAttendanceFlag(boolean markAttendanceFlag) {
		this.markAttendanceFlag = markAttendanceFlag;
	}


	public Address getAddress() {
		return address;
	}


	public void setAddress(Address address) {
		this.address = address;
	}

	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	public Set<Attendance> getAttendance() {
		return attendance;
	}


	public void setAttendance(Set<Attendance> attendance) {
		this.attendance = attendance;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((empId == null) ? 0 : empId.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Employee))
			return false;
		Employee other = (Employee) obj;
		if (empId == null) {
			if (other.empId != null)
				return false;
		} else if (!empId.equals(other.empId))
			return false;
		return true;
	}
	
	
	
}
