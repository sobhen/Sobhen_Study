package com.abhyudayatrust.data.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.abhyudayatrust.data.entities.User;

public class UserDao extends BaseDao<User> {

	@Override
	public User getById(Integer id) {
		return null;
	}

	@Override
	public List<User> listAll() {
		return null;
	}

	public User getUserDetail(String userId) {
		User user = null;

		Session session = getSession();

		Query query = session.createQuery("from User where userId=?");

		query.setString(0, userId);

		user = (User) query.uniqueResult();

		return user;
	}
}
