package com.abhyudayatrust.data.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import com.abhyudayatrust.data.entities.User;

public class UserDao extends BaseDao<User> {

	@Override
	public User getById(Integer id) {
		return null;
	}

	@Override
	public List<User> listAll() {
		return null;
	}

	public User getUserDetail(String userId) {
		User user = null;		
		
		Criteria criteria =  getSession().createCriteria(User.class)
				.add(Restrictions.eq("userId", userId));
		user = (User) criteria.uniqueResult();
				
		return user;
	}
	
	public void updateLastLoginTime(String userId){
		Session session = getSession();		
		
		Query query = session.createQuery("update User set lastLoginTime=:lastLoginTime where userId=:userId");
		query.setTimestamp("lastLoginTime", new java.sql.Timestamp(new java.util.Date().getTime()));
		query.setString("userId", userId);

		query.executeUpdate();
	}
}
