package com.abhyudayatrust.data.dao;

import java.util.List;

public interface IBaseDao<T> {
	
	public T getById(Integer id);
	
	public List<T> listAll();
	
}
