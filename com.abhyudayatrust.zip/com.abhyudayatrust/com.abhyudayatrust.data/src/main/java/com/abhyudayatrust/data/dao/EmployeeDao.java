package com.abhyudayatrust.data.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import com.abhyudayatrust.data.entities.Employee;
import com.abhyudayatrust.data.entities.User;

public class EmployeeDao extends BaseDao<Employee> {



	public Employee getEmployeeByUserId(User user){
		
		Employee emp = null;
		
		Criteria criteria = getSession().createCriteria(Employee.class)
				.add(Restrictions.eq("user", user));
		
		emp = (Employee) criteria.uniqueResult();
		return emp;
		
	}

	@Override
	public Employee getById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> listAll() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
