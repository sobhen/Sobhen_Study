package com.abhyudayatrust.data.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.abhyudayatrust.data.entities.Role;

public class RoleDao extends BaseDao<Role> {

	@Override
	public Role getById(Integer id) {		
		Role role = getSession().get(Role.class, id);
		return role;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Role> listAll() {

		Session session = getSession();
		// Transaction tx = session.beginTransaction();

		List<Role> roleList = session.createCriteria(Role.class).list();

		// tx.commit();
		return roleList;
	}

	public Integer createRole(Role role){
		Integer generatedId = null;
		
		getSession().save(role);
		
		return generatedId;
	}
	
/*  SELECT menu.MENU,subMenu.SUBMENU,subMenu.URL
	FROM T_ROLE role JOIN T_ROLE_AUTHORITIES roleAuth ON role.ROLE_ID = roleAuth.ROLE_ID
	JOIN T_SUBMENU subMenu ON roleAuth.SUBMENU_ID = subMenu.SUBMENU_ID
	JOIN T_MENU menu ON  subMenu.MENU_ID = menu.MENU_ID
	WHERE role.ROLE_ID = ?
	ORDER BY  menu.SORT_ORDER,subMenu.SORT_ORDER
*/
	
	public List<Object[]> getRoleWithAccessByRoleId(Integer id){
 		Session session = getSession();
		
		//Transaction tx = session.beginTransaction();
		
		Criteria criteria = session.createCriteria(Role.class)
				.createAlias("subMenus", "submenu")
				.createAlias("submenu.menu", "menu")
				.setProjection(
						Projections.projectionList()
						.add(Projections.property("menu.menu"))
						.add(Projections.property("submenu.subMenu"))
						.add(Projections.property("submenu.url"))
				  )
				.add(Restrictions.idEq(id))
				.addOrder(Order.asc("menu.sortOrder"))
				.addOrder(Order.asc("submenu.sortOrder"));

		
		@SuppressWarnings("unchecked")
		List<Object[]> menus = criteria.list();
		
		//System.out.println(menusList);
		
		//tx.commit();
		return menus;
	}
	
}
