package com.abhyudayatrust.data.dao;

import java.sql.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import com.abhyudayatrust.data.entities.Attendance;
import com.abhyudayatrust.data.entities.Employee;

public class AttendanceDao extends BaseDao<Attendance>{

	@Override
	public Attendance getById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Attendance> listAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public Attendance getAttendanceByDate(Employee employee, Date date)
	{
		Attendance attendance = null;
		
		Criteria criteria = getSession().createCriteria(Attendance.class)
				.add(Restrictions.eq("attendanceDate", date))
				.add(Restrictions.eq("employee", employee));
		
		attendance = (Attendance) criteria.uniqueResult();
		return attendance;
	}
	
	public void markAttendance(Employee employee){
		
	}
	
}
