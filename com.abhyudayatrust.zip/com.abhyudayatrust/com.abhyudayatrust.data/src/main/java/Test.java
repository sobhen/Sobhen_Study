import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.transaction.Transaction;

import org.hibernate.Query;
import org.hibernate.Session;

import com.abhyudayatrust.data.dao.RoleDao;
import com.abhyudayatrust.data.dao.UserDao;
import com.abhyudayatrust.data.entities.Menu;
import com.abhyudayatrust.data.entities.Page;
import com.abhyudayatrust.data.entities.PageFunction;
import com.abhyudayatrust.data.entities.Role;
import com.abhyudayatrust.data.entities.SubMenu;
import com.abhyudayatrust.data.entities.User;
import com.abhyudayatrust.data.util.HibernateUtil;


public class Test {

	public static void main(String[] args) {
		
		Session session = HibernateUtil.getSession();
		org.hibernate.Transaction tx = session.beginTransaction();
		
		
		/*Page page = new Page();
		page.setPage("Add Income/Expense");
		
		
		PageFunction pageFunction1 = new PageFunction();
		pageFunction1.setFunction("Add");		
		pageFunction1.setPage(page);
		
		PageFunction pageFunction2 = new PageFunction();		
		pageFunction2.setFunction("Edit");
		pageFunction2.setPage(page);
		
		PageFunction pageFunction3 = new PageFunction();		
		pageFunction3.setFunction("View");
		pageFunction3.setPage(page);
		
		Set<PageFunction> pageFunctions = new HashSet<PageFunction>();
		pageFunctions.add(pageFunction1);
		pageFunctions.add(pageFunction2);
		pageFunctions.add(pageFunction3);
		
		
		SubMenu subMenu1 = new SubMenu();	
		
		page.setPageFunctions(pageFunctions);
		page.setSubMenu(subMenu1);
		Set<Page> pages = new HashSet<Page>();
		pages.add(page);
		
		
		Menu menu = new Menu();
		menu.setMenu("TestMenu");
		menu.setSortOrder(1);
		
			
		subMenu1.setSubMenu("TestSubMenu1");
		subMenu1.setUrl("http://test1");
		subMenu1.setSortOrder(1);		
		subMenu1.setPages(pages);
		subMenu1.setMenu(menu);
		
		SubMenu subMenu2 = new SubMenu();		
		subMenu2.setSubMenu("TestSubMenu2");
		subMenu2.setUrl("http://test2");
		subMenu2.setSortOrder(2);	
		subMenu2.setMenu(menu);
		
		Set<SubMenu> subMenus = new  HashSet<SubMenu>();
		subMenus.add(subMenu1);
		subMenus.add(subMenu2);
		
		
		
		menu.setSubMenus(subMenus);
		
		
		Role role = new Role();
		role.setRoleName("DummyRole");
		role.setRoleDesc("DummyRole");
		role.setSubMenus(subMenus);
		
		session.save(role);*/
		
		/*Role role = session.get(Role.class, 2);
		
		User user = new User();
		
		
		
		user.setUserName("Sobhen1");
		user.setUserId("SOBHEN1");
		user.setUserStatus('A');
		user.setLoginPassword("Password");
		user.setNewPassFlag(true);
		user.setValidityFrom(new Date(12334));
		user.setValidityTo(new Date(12334));
		user.setRole(role);
		
		
		
		session.save(user);*/
		
		
		
		/*Query query = session.createQuery("from User where userId=?");

		query.setString(0, "admin");

		User user = (User) query.uniqueResult();
		
		System.out.println(user.getUserName() +" :: "+ user.getRole().getRoleName());
		System.out.println(user.getRole().getSubMenus());
		session.flush();
		tx.commit();
		session.close();*/
		
		//System.out.println(new RoleDao().listAll());
		
		
			
	}
	

}
