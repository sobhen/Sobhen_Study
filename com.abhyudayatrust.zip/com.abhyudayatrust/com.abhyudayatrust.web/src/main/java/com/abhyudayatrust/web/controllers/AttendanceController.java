package com.abhyudayatrust.web.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class AttendanceController {

	
}
