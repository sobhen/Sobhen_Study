package com.abhyudayatrust.web.controllers;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.JstlView;

import com.abhyudayatrust.common.model.LoginBean;
import com.abhyudayatrust.common.model.User;
import com.abhyudayatrust.services.AttendanceService;
import com.abhyudayatrust.services.RoleService;
import com.abhyudayatrust.services.UserService;


@Controller
public class AuthenticationController {
	
	@Autowired
	private RoleService roleService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private AttendanceService attendanceService;
	
	@RequestMapping(value="/loginPage",method=RequestMethod.GET)
	public ModelAndView displayLogin(){	
		ModelAndView model = new ModelAndView();
		LoginBean loginBean = new LoginBean();
		JstlView view = new JstlView("/WEB-INF/views/login.jsp");
		model.setView(view);
		model.addObject("loginBean", loginBean);
		return model;
	}

	@RequestMapping(value="/index",method=RequestMethod.GET)
	public ModelAndView index(){	
		
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		User user = (User)authentication.getPrincipal();
		
		Map<Object, List<Object[]>> userMenuMap = roleService.fetchMenusByRoleId(user.getRole().getRoleId());
		
		ModelAndView model = new ModelAndView();		
		model.addObject("user", user);
		model.addObject("userMenuMap", userMenuMap);
	
		model.addObject("hasUserMarkedAttendanceToday", attendanceService.hasUserMarkedAttendanceToday(user));
		
		model.setViewName("home");	
		return model;		
	}
	
	@RequestMapping(value="/logout", method = RequestMethod.GET)
	public String logoutPage (HttpServletRequest request, HttpServletResponse response) {
	    Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	    if (auth != null){    
	        new SecurityContextLogoutHandler().logout(request, response, auth);
	    }	    
	    return "redirect:/loginPage?logout";
	}
	

}
