package com.abhyudayatrust.web.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.abhyudayatrust.web.model.LoginBean;

@Controller
public class LoginController {
	
	@RequestMapping(value="/login",method=RequestMethod.GET)
	public ModelAndView displayLogin(){
		System.out.println("Inside LoginController displayLogin()");
		ModelAndView model = new ModelAndView();
		LoginBean loginBean = new LoginBean();
		model.setViewName("login");
		model.addObject("loginBean", loginBean);
		return model;
	}

	/*
	 * @RequestMapping(value="/login",method=RequestMethod.POST) public String
	 * login(@ModelAttribute("loginBean") LoginBean loginBean){
	 * System.out.println("Inside LoginController login()");
	 * 
	 * System.out.println(loginBean.getTxtuid());
	 * System.out.println(loginBean.getPassword());
	 * System.out.println(loginBean.getTxtdomain()); return "home"; }
	 */
}
