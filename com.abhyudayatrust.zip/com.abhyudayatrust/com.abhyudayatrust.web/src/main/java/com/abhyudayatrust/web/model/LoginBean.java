package com.abhyudayatrust.web.model;

public class LoginBean {

	private String txtuid;
	private String password;
	private String txtdomain;
	
	public String getTxtuid() {
		return txtuid;
	}
	public void setTxtuid(String txtuid) {
		this.txtuid = txtuid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getTxtdomain() {
		return txtdomain;
	}
	public void setTxtdomain(String txtdomain) {
		this.txtdomain = txtdomain;
	}
	
	
}