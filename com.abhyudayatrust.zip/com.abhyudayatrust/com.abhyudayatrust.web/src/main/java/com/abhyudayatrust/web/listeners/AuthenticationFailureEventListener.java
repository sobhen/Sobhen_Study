package com.abhyudayatrust.web.listeners;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import org.springframework.context.ApplicationListener;
import org.springframework.security.authentication.event.AuthenticationFailureBadCredentialsEvent;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
@Component
public class AuthenticationFailureEventListener implements
		ApplicationListener<AuthenticationFailureBadCredentialsEvent> {

	

	@Override
	public void onApplicationEvent(
			AuthenticationFailureBadCredentialsEvent event) {
		
		System.out.println("Inside AuthenticationFailureEventListener :: onApplicationEvent");
		
		/*WebAuthenticationDetails auth = (WebAuthenticationDetails) event
				.getAuthentication().getDetails();*/
		
	}
}

