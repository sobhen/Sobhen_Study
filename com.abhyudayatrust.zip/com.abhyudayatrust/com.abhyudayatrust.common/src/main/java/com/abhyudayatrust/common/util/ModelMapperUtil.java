package com.abhyudayatrust.common.util;

import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;

/*
 * Something needs to be done to remove duplicate codes here.
 * May be Use AOP. Think later??
 */

public class ModelMapperUtil {	

	public static <S, D> D toModel(S sourceType, Class<D> destinationType) {
		ModelMapper mapper = new ModelMapper();
		return mapper.map(sourceType, destinationType);
	}

	public static <S, D> D toEntity(S sourceType, Class<D> destinationType) {
		ModelMapper mapper = new ModelMapper();
		return mapper.map(sourceType, destinationType);
	}

	public static <S, D> D toModel(S sourceType, Class<D> destinationType,PropertyMap<S, D> propertyMap) {
		ModelMapper mapper = new ModelMapper();
		mapper.addMappings(propertyMap);
		D returnval = mapper.map(sourceType, destinationType);
		return returnval;
	}

	public static <S, D> D toEntity(S sourceType, Class<D> destinationType,PropertyMap<S, D> propertyMap) {
		ModelMapper mapper = new ModelMapper();
		mapper.addMappings(propertyMap);
		D returnval = mapper.map(sourceType, destinationType);
		return returnval;
	}

}
