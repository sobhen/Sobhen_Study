package com.abhyudayatrust.common.model;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;

public class User extends org.springframework.security.core.userdetails.User
		implements Serializable {

	private static final long serialVersionUID = -3632620330020660629L;

	private Integer id;
	private String userDisplayName;

	// UserID is same as Spring security UserName
	private String userId;

	// userStatus is same as Spring security enabled
	private char userStatus;

	private String loginPassword;
	private Date validityFrom;
	private Date validityTo;
	private Timestamp lastLoginTime;
	private Integer failLogin;
	private boolean newPassFlag;
	private Date passwordChangeDate;
	private Integer passwordRetries;
	private byte[] passwordSalt;
	private Role role;
	private Employee employee;
	

	public User(String username, String password,
			Collection<? extends GrantedAuthority> authorities) {

		super(username, password, authorities);

	}

	public User(String username, String password, boolean enabled,
			boolean accountNonExpired, boolean credentialsNonExpired,
			boolean accountNonLocked,
			Collection<? extends GrantedAuthority> authorities) {

		super(username, password, enabled, accountNonExpired,
				credentialsNonExpired, accountNonLocked, authorities);
	}
		
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUserDisplayName() {
		return userDisplayName;
	}

	public void setUserDisplayName(String userDisplayName) {
		this.userDisplayName = userDisplayName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public char getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(char userStatus) {
		this.userStatus = userStatus;
	}

	public String getLoginPassword() {
		return loginPassword;
	}

	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}

	public Date getValidityFrom() {
		return validityFrom;
	}

	public void setValidityFrom(Date validityFrom) {
		this.validityFrom = validityFrom;
	}

	public Date getValidityTo() {
		return validityTo;
	}

	public void setValidityTo(Date validityTo) {
		this.validityTo = validityTo;
	}

	public Timestamp getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(Timestamp lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public Integer getFailLogin() {
		return failLogin;
	}

	public void setFailLogin(Integer failLogin) {
		this.failLogin = failLogin;
	}

	public boolean isNewPassFlag() {
		return newPassFlag;
	}

	public void setNewPassFlag(boolean newPassFlag) {
		this.newPassFlag = newPassFlag;
	}

	public Date getPasswordChangeDate() {
		return passwordChangeDate;
	}

	public void setPasswordChangeDate(Date passwordChangeDate) {
		this.passwordChangeDate = passwordChangeDate;
	}

	public Integer getPasswordRetries() {
		return passwordRetries;
	}

	public void setPasswordRetries(Integer passwordRetries) {
		this.passwordRetries = passwordRetries;
	}

	public byte[] getPasswordSalt() {
		return passwordSalt;
	}

	public void setPasswordSalt(byte[] passwordSalt) {
		this.passwordSalt = passwordSalt;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	
	

}
