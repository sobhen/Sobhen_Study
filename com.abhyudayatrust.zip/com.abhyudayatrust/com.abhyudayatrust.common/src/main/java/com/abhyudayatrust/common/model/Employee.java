package com.abhyudayatrust.common.model;

import java.io.Serializable;
import java.sql.Date;

public class Employee implements Serializable {

	private static final long serialVersionUID = 5755054281283160523L;

	private Integer id;
	private String empId;
	private String firstName;
	private String middleName;
	private String lastName;
	private char empStatus;
	private Date joiningDate;
	private Date dateOfBirth;
	private char gender;
	private boolean markAttendanceFlag;
	private Address address;
	//private User user;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getEmpStatus() {
		return empStatus;
	}
	public void setEmpStatus(char empStatus) {
		this.empStatus = empStatus;
	}
	public Date getJoiningDate() {
		return joiningDate;
	}
	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public boolean isMarkAttendanceFlag() {
		return markAttendanceFlag;
	}
	public void setMarkAttendanceFlag(boolean markAttendanceFlag) {
		this.markAttendanceFlag = markAttendanceFlag;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	
	
	

}
