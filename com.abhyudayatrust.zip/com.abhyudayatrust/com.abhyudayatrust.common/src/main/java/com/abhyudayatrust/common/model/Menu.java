package com.abhyudayatrust.common.model;

import java.io.Serializable;
import java.util.Set;

public class Menu implements Serializable {

	private static final long serialVersionUID = -7612921816655082988L;

	private Integer menuId;

	private String menu;

	private Integer sortOrder;

	private Set<SubMenu> subMenus;

	public Integer getMenuId() {
		return menuId;
	}

	public void setMenuId(Integer menuId) {
		this.menuId = menuId;
	}

	public String getMenu() {
		return menu;
	}

	public void setMenu(String menu) {
		this.menu = menu;
	}

	public Integer getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(Integer sortOrder) {
		this.sortOrder = sortOrder;
	}

	public Set<SubMenu> getSubMenus() {
		return subMenus;
	}

	public void setSubMenus(Set<SubMenu> subMenus) {
		this.subMenus = subMenus;
	}

	@Override
	public String toString() {
		return "Menu [menuId=" + menuId + ", menu=" + menu + ", sortOrder="
				+ sortOrder + ", subMenus=" + subMenus + "]";
	}
	

}
