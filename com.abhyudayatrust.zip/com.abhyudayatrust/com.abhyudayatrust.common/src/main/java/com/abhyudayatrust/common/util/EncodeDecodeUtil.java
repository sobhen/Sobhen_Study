package com.abhyudayatrust.common.util;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.crypto.password.Pbkdf2PasswordEncoder;

public class EncodeDecodeUtil {

	public static void main(String[] args) {
		PasswordEncoder encoder = new Pbkdf2PasswordEncoder();
		System.out.println(encoder.encode("adminpass"));

	}

}
