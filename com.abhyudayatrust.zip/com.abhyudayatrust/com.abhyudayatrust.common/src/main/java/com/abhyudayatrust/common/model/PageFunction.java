package com.abhyudayatrust.common.model;

import java.io.Serializable;

public class PageFunction implements Serializable {

	private static final long serialVersionUID = -2985186058557788350L;

	private Integer functionId;

	private String function;

	public Integer getFunctionId() {
		return functionId;
	}

	public void setFunctionId(Integer functionId) {
		this.functionId = functionId;
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}

}
