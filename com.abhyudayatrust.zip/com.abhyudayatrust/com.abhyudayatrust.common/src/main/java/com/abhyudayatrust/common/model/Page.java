package com.abhyudayatrust.common.model;

import java.io.Serializable;
import java.util.Set;

public class Page implements Serializable {

	private static final long serialVersionUID = 9084191654711513128L;

	private Integer pageId;

	private String page;

	private Set<PageFunction> pageFunctions;

	public Integer getPageId() {
		return pageId;
	}

	public void setPageId(Integer pageId) {
		this.pageId = pageId;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public Set<PageFunction> getPageFunctions() {
		return pageFunctions;
	}

	public void setPageFunctions(Set<PageFunction> pageFunctions) {
		this.pageFunctions = pageFunctions;
	}

}
