package com.abhyudayatrust.common.model;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

public class Attendance implements Serializable {

	private static final long serialVersionUID = -542167195105536404L;

	private Integer id;
	private Employee employee;
	private Date attendanceDate;
	private Timestamp checkInTime;
	private Timestamp checkOutTime;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	public Date getAttendanceDate() {
		return attendanceDate;
	}
	public void setAttendanceDate(Date attendanceDate) {
		this.attendanceDate = attendanceDate;
	}
	public Timestamp getCheckInTime() {
		return checkInTime;
	}
	public void setCheckInTime(Timestamp checkInTime) {
		this.checkInTime = checkInTime;
	}
	public Timestamp getCheckOutTime() {
		return checkOutTime;
	}
	public void setCheckOutTime(Timestamp checkOutTime) {
		this.checkOutTime = checkOutTime;
	}
	@Override
	public String toString() {
		return "Attendance [id=" + id + ", employee=" + employee
				+ ", attendanceDate=" + attendanceDate + ", checkInTime="
				+ checkInTime + ", checkOutTime=" + checkOutTime + "]";
	}
	
	
}
