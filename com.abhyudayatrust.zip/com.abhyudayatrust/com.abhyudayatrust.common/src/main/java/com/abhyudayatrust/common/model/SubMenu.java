package com.abhyudayatrust.common.model;

import java.io.Serializable;
import java.util.Set;

public class SubMenu implements Serializable {

	private static final long serialVersionUID = -1633946045925120594L;

	private Integer submenuId;

	private String subMenu;

	private Integer sortOrder;

	private String url;

	private Set<Page> pages;

	public Integer getSubmenuId() {
		return submenuId;
	}

	public void setSubmenuId(Integer submenuId) {
		this.submenuId = submenuId;
	}

	public String getSubMenu() {
		return subMenu;
	}

	public void setSubMenu(String subMenu) {
		this.subMenu = subMenu;
	}

	public Integer getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(Integer sortOrder) {
		this.sortOrder = sortOrder;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Set<Page> getPages() {
		return pages;
	}

	public void setPages(Set<Page> pages) {
		this.pages = pages;
	}

	@Override
	public String toString() {
		return "SubMenu [submenuId=" + submenuId + ", subMenu=" + subMenu
				+ ", sortOrder=" + sortOrder + ", url=" + url + ", pages="
				+ pages + "]";
	}

}
