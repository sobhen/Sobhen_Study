## Weather

    <Weather />

The `Weather` component demonstrates a component that caches weather for a specified amount of time.
