## Messages

    const data = require('./data.js')(10);
    <Messages messages={data.messages} users={data.users} />
